package com.mds.inventario.inventario.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InventarioDto {

    private Integer id;
    private String cod;
    private Double exist;
    private Double cmp;
    private Integer semana;
    private Timestamp fecha;
}
