package com.mds.inventario.inventario.service;

import com.mds.inventario.inventario.data.InventarioDto;
import com.mds.inventario.inventario.entity.InventorioEntity;
import com.mds.inventario.inventario.repository.InventarioRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InventarioService {

    private final InventarioRepository repository;
    private final ModelMapper modelMapper;

    public List<InventarioDto> findAll() {
        return repository.findAll().stream()
                .map(e -> modelMapper.map(e, InventarioDto.class))
                .collect(Collectors.toList());
    }


    public Optional<InventarioDto> findById(Integer id) {
        return repository.findById(id)
                .map(e -> modelMapper.map(e, InventarioDto.class));
    }

    public InventarioDto save(InventarioDto dto) {
        InventorioEntity entity = modelMapper.map(dto, InventorioEntity.class);
        InventorioEntity saved = repository.save(entity);
        return modelMapper.map(saved, InventarioDto.class);
    }

    public void delete(Integer id) {
        repository.deleteById(id);
    }
}
