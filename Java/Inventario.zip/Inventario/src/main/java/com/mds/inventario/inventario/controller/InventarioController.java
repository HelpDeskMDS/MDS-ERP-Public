package com.mds.inventario.inventario.controller;

import com.mds.inventario.inventario.data.InventarioDto;
import com.mds.inventario.inventario.service.InventarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
@RequiredArgsConstructor
public class InventarioController {

    private final InventarioService service;

    @GetMapping
    public List<InventarioDto> getAll() {
        return service.findAll();
    }

   /* @GetMapping("/test-raw")
    public List<InventorioEntity> getRaw() {
        return service.findAll();
    }*/


    @GetMapping("/{id}")
    public ResponseEntity<InventarioDto> getById(@PathVariable Integer id) {
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public InventarioDto create(@RequestBody InventarioDto dto) {
        return service.save(dto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InventarioDto> update(@PathVariable Integer id, @RequestBody InventarioDto dto) {
        if (!service.findById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        dto.setId(id);
        return ResponseEntity.ok(service.save(dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        if (!service.findById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
