package com.mds.inventario.inventario.repository;

import com.mds.inventario.inventario.entity.InventorioEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InventarioRepository extends JpaRepository<InventorioEntity, Integer> {
}
