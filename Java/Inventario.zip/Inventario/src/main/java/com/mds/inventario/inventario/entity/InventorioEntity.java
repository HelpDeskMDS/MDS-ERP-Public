package com.mds.inventario.inventario.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "SaldosInventario", schema = "dbo")
public class InventorioEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "COD", nullable = true, length = 20)
    private String cod;

    @Column(name = "EXIST", nullable = true)
    private Double exist;

    @Column(name = "CMP", nullable = true)
    private Double cmp;

    @Column(name = "SEMANA", nullable = true)
    private Integer semana;

    @Column(name = "FECHA", nullable = true)
    private Timestamp fecha; // o java.sql.Timestamp si tienes problemas
}
